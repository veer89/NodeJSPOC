var args = arguments[0] || {};


// if back Btn param available, set it
if(args.backBtn){
	$.backBtn.visible = args.backBtn;
}

// if title param available, set it
if(args.title){
	$.header.text = args.title;

function closeEdit(){
	
}

function editProfile(){	

}
