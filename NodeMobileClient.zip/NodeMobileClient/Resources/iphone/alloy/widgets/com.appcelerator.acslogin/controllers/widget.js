function WPATH(s) {
    var index = s.lastIndexOf("/");
    var path = -1 === index ? "com.appcelerator.acslogin/" + s : s.substring(0, index) + "/com.appcelerator.acslogin/" + s.substring(index + 1);
    return path;
}

function Controller() {
    function activityIndicator() {
        var style;
        style = Ti.UI.iPhone.ActivityIndicatorStyle.DARK;
        return Ti.UI.createActivityIndicator({
            color: "#ffffff",
            style: style,
            height: Ti.UI.SIZE,
            width: Ti.UI.SIZE
        });
    }
    function loginClick() {
        if ($.usernameTxt.value && $.passwordTxt.value) {
            $.usernameTxt.blur();
            $.passwordTxt.blur();
            $.loginLbl.text = "";
            var actInd = activityIndicator();
            $.loginBtn.add(actInd);
            actInd.show();
            settings.loginCallback && settings.loginCallback({
                username: $.usernameTxt.value,
                password: $.passwordTxt.value
            });
        }
    }
    function moveLoginContainer(evt) {
        Ti.App.keyboardVisible ? $.loginContainer.animate({
            center: {
                x: Ti.Platform.displayCaps.platformWidth / 2,
                y: "ipad" === Ti.Platform.osname ? (Ti.Platform.displayCaps.platformHeight - evt.keyboardFrame.height) / 2 - 10 : (Ti.Platform.displayCaps.platformHeight - evt.keyboardFrame.height) / 2
            },
            duration: 250
        }) : $.loginContainer.animate({
            center: {
                x: Ti.Platform.displayCaps.platformWidth / 2,
                y: Ti.Platform.displayCaps.platformHeight / 2
            },
            duration: 250
        });
    }
    new (require("alloy/widget"))("com.appcelerator.acslogin");
    this.__widgetId = "com.appcelerator.acslogin";
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "widget";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.acsloginMain = Ti.UI.createView({
        backgroundColor: "black",
        id: "acsloginMain"
    });
    $.__views.acsloginMain && $.addTopLevelView($.__views.acsloginMain);
    $.__views.loginContainer = Ti.UI.createView({
        backgroundImage: "/common/login-bg-flex.png",
        backgroundTopCap: 14,
        backgroundLeftCap: 12,
        width: 319,
        height: 164,
        layout: "vertical",
        id: "loginContainer"
    });
    $.__views.acsloginMain.add($.__views.loginContainer);
    $.__views.titleContainer = Ti.UI.createView({
        top: 2,
        layout: "vertical",
        height: Ti.UI.SIZE,
        id: "titleContainer"
    });
    $.__views.loginContainer.add($.__views.titleContainer);
    $.__views.header = Ti.UI.createView({
        height: 150,
        width: 319,
        top: 0,
        id: "header"
    });
    $.__views.titleContainer.add($.__views.header);
    $.__views.headerTitle = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        color: "black",
        id: "headerTitle",
        text: "NodeJS Demo"
    });
    $.__views.header.add($.__views.headerTitle);
    $.__views.divider = Ti.UI.createView({
        height: 2,
        width: 309,
        backgroundImage: "/common/divider.png",
        opacity: 0,
        id: "divider"
    });
    $.__views.titleContainer.add($.__views.divider);
    $.__views.msgLbl = Ti.UI.createLabel({
        top: 5,
        height: 0,
        color: "#000000",
        textAlign: Ti.UI.TEXT_ALIGNMENT_CENTER,
        font: {
            fontSize: "14dp"
        },
        shadowOffset: 1,
        shadowColor: "#363636",
        width: "80%",
        id: "msgLbl"
    });
    $.__views.titleContainer.add($.__views.msgLbl);
    $.__views.bodyContainer = Ti.UI.createView({
        top: 0,
        height: Ti.UI.SIZE,
        id: "bodyContainer"
    });
    $.__views.loginContainer.add($.__views.bodyContainer);
    $.__views.acsLogin = Ti.UI.createView({
        top: 0,
        height: Ti.UI.SIZE,
        width: Ti.UI.FILL,
        layout: "vertical",
        opacity: 0,
        id: "acsLogin"
    });
    $.__views.bodyContainer.add($.__views.acsLogin);
    $.__views.usernameTxt = Ti.UI.createTextField({
        color: "#333",
        height: 50,
        left: 20,
        right: 20,
        backgroundImage: "/common/field-bg.png",
        backgroundLeftCap: 8,
        backgroundTopCap: 24,
        paddingLeft: 15,
        autocapitalize: false,
        autocorrect: false,
        top: 16,
        hintText: "Username",
        returnKeyType: Ti.UI.RETURNKEY_NEXT,
        id: "usernameTxt"
    });
    $.__views.acsLogin.add($.__views.usernameTxt);
    $.__views.passwordTxt = Ti.UI.createTextField({
        color: "#333",
        height: 50,
        left: 20,
        right: 20,
        backgroundImage: "/common/field-bg.png",
        backgroundLeftCap: 8,
        backgroundTopCap: 24,
        paddingLeft: 15,
        autocapitalize: false,
        autocorrect: false,
        top: 4,
        hintText: "Password",
        passwordMask: true,
        id: "passwordTxt"
    });
    $.__views.acsLogin.add($.__views.passwordTxt);
    $.__views.__alloyId0 = Ti.UI.createView({
        top: 17,
        left: 20,
        right: 20,
        height: Ti.UI.SIZE,
        id: "__alloyId0"
    });
    $.__views.acsLogin.add($.__views.__alloyId0);
    $.__views.helpImg = Ti.UI.createButton({
        height: 25,
        width: 25,
        left: 25,
        backgroundImage: "/common/help-btn.png",
        backgroundSelectedImage: "/common/help-btn-touch.png",
        id: "helpImg"
    });
    $.__views.__alloyId0.add($.__views.helpImg);
    $.__views.forgotLbl = Ti.UI.createLabel({
        height: 25,
        color: "#999",
        font: {
            fontSize: 12
        },
        shadowOffset: 1,
        shadowColor: "#363636",
        left: 52,
        text: "Forgot Password",
        id: "forgotLbl"
    });
    $.__views.__alloyId0.add($.__views.forgotLbl);
    $.__views.loginBtn = Ti.UI.createView({
        height: 44,
        top: 0,
        backgroundImage: "/common/btn-light-flex.png",
        backgroundSelectedImage: "/common/btn-light-touch-flex.png",
        backgroundLeftCap: 5,
        width: 100,
        right: 3,
        id: "loginBtn"
    });
    $.__views.__alloyId0.add($.__views.loginBtn);
    loginClick ? $.__views.loginBtn.addEventListener("click", loginClick) : __defers["$.__views.loginBtn!click!loginClick"] = true;
    $.__views.loginLbl = Ti.UI.createLabel({
        color: "#000000",
        font: {
            fontSize: 14
        },
        textAlign: "center",
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        text: "Login",
        id: "loginLbl"
    });
    $.__views.loginBtn.add($.__views.loginLbl);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var settings = {
        loginCallback: null,
        createCallback: null
    };
    $.loginClick = function() {
        loginClick();
    };
    Ti.App.addEventListener("keyboardframechanged", moveLoginContainer);
    $.init = function(params) {
        settings.loginCallback = params.loginCallback;
    };
    $.open = function() {
        setTimeout(function() {
            $.loginContainer.animate({
                height: 361,
                duration: 250
            }, function() {
                $.acsLogin.animate({
                    opacity: 1,
                    duration: 250
                });
                $.divider.animate({
                    opacity: 1,
                    duration: 250
                });
                $.loginContainer.height = 361;
            });
        }, 1e3);
    };
    $.close = function() {
        Ti.App.removeEventListener("keyboardframechanged", moveLoginContainer);
        $.destroy();
        Alloy.CFG.skipLogin = false;
    };
    $.open();
    __defers["$.__views.loginBtn!click!loginClick"] && $.__views.loginBtn.addEventListener("click", loginClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;