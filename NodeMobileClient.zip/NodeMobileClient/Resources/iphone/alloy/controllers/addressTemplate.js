function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "addressTemplate";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    $.__views.addressWrapper = Ti.UI.createView({
        height: Ti.UI.SIZE,
        width: Ti.UI.FILL,
        top: 0,
        layout: "vertical",
        touchEnabled: false,
        id: "addressWrapper"
    });
    $.__views.addressWrapper && $.addTopLevelView($.__views.addressWrapper);
    $.__views.header = Ti.UI.createView({
        height: 45,
        width: Ti.UI.FILL,
        backgroundColor: "gray",
        id: "header"
    });
    $.__views.addressWrapper.add($.__views.header);
    $.__views.projectName = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        color: "#ffffff",
        left: 10,
        id: "projectName"
    });
    $.__views.header.add($.__views.projectName);
    $.__views.__alloyId1 = Ti.UI.createView({
        top: 0,
        height: 45,
        width: Ti.UI.FILL,
        id: "__alloyId1"
    });
    $.__views.addressWrapper.add($.__views.__alloyId1);
    $.__views.__alloyId2 = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        color: "#ffffff",
        left: 10,
        textAlign: "left",
        text: "On Team Since:",
        id: "__alloyId2"
    });
    $.__views.__alloyId1.add($.__views.__alloyId2);
    $.__views.duration = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: 150,
        color: "#ffffff",
        right: 10,
        textAlign: "right",
        id: "duration"
    });
    $.__views.__alloyId1.add($.__views.duration);
    $.__views.__alloyId3 = Ti.UI.createView({
        height: 1,
        width: Ti.UI.FILL,
        left: 10,
        right: 10,
        backgroundColor: "#ffe1b5",
        bottom: 0,
        id: "__alloyId3"
    });
    $.__views.__alloyId1.add($.__views.__alloyId3);
    $.__views.__alloyId4 = Ti.UI.createView({
        top: 0,
        height: 45,
        width: Ti.UI.FILL,
        id: "__alloyId4"
    });
    $.__views.addressWrapper.add($.__views.__alloyId4);
    $.__views.__alloyId5 = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        color: "#ffffff",
        left: 10,
        textAlign: "left",
        text: "Location:",
        id: "__alloyId5"
    });
    $.__views.__alloyId4.add($.__views.__alloyId5);
    $.__views.location = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: 150,
        color: "#ffffff",
        right: 10,
        textAlign: "right",
        id: "location"
    });
    $.__views.__alloyId4.add($.__views.location);
    $.__views.__alloyId6 = Ti.UI.createView({
        height: 1,
        width: Ti.UI.FILL,
        left: 10,
        right: 10,
        backgroundColor: "#ffe1b5",
        bottom: 0,
        id: "__alloyId6"
    });
    $.__views.__alloyId4.add($.__views.__alloyId6);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var params = arguments[0] || {};
    var data = params.projectInfo;
    $.projectName.text = data.projectName;
    $.duration.text = data.projectDuration;
    $.location.text = data.projectLocation;
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;