function Controller() {
    function init() {
        for (var i = 0, length = params.projectData.length; length > i; i++) {
            var addressTemplate = Alloy.createController("addressTemplate", {
                projectInfo: params.projectData[i]
            }).getView();
            $.container.add(addressTemplate);
        }
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "addressDetails";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    $.__views.detailWin = Ti.UI.createWindow({
        navBarHidden: true,
        layout: "vertical",
        id: "detailWin"
    });
    $.__views.detailWin && $.addTopLevelView($.__views.detailWin);
    $.__views.navBar = Alloy.createController("navBar", {
        id: "navBar",
        backBtn: "true",
        title: "Address",
        __parentSymbol: $.__views.detailWin
    });
    $.__views.navBar.setParent($.__views.detailWin);
    $.__views.container = Ti.UI.createView({
        height: Ti.UI.FILL,
        width: Ti.UI.FILL,
        backgroundColor: "black",
        layout: "vertical",
        id: "container"
    });
    $.__views.detailWin.add($.__views.container);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var params = arguments[0] || {};
    Alloy.Globals.iOS7 && ($.detailWin.top = 20);
    $.navBar.backBtn.addEventListener("singletap", function() {
        $.detailWin.close();
    });
    init();
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;