function Controller() {
    function init() {
        var apiData = {
            userId: params.userId ? params : "5348d3098337140000bbc0df",
            callback: {
                successCallback: userSuccessCallback,
                errorCallback: errorCallback
            }
        };
        apiClient.sendRequest(endPoints.users.show, null, null, [ apiData.userId ], apiData.callback);
        var apiAddressData = {
            userId: params.userId ? params : "5348d3098337140000bbc0df",
            callback: {
                successCallback: addressSuccessCallback,
                errorCallback: errorCallback
            }
        };
        apiClient.sendRequest(endPoints.address.showByEmpId, null, null, [ apiData.userId ], apiAddressData.callback);
    }
    function setUserData(data) {
        $.profilePic.image = data && data.img && data.img.data ? data.img.data : "/images/defaultProfile.png";
        $.name.text = data && data.first_name ? data.first_name + " " + (data.last_name ? data.last_name : "") : "NA";
        $.designation.text = data && data.designation ? data.designation : "NA";
        $.empId.text = data && data.empId ? data.empId : "NA";
        $.emailId.text = data && data.emailId ? data.emailId : "NA";
        $.phoneNumber.text = data && data.phone_number ? data.phone_number : "NA";
    }
    function addressSuccessCallback(response) {
        console.log("success" + JSON.stringify(response));
        if ("200" == response.meta.status) {
            var data = response.data;
            var address = data.street ? data.street + " " + (data.city ? data.city : " " + (data.pin ? data.pin : " " + (data.country ? data.country : ""))) : "NA";
            $.address.text = address;
        } else errorCallback({
            message: "No data found for this user"
        });
    }
    function userSuccessCallback(response) {
        console.log("success" + JSON.stringify(response));
        if ("200" == response.meta.status) {
            var data = response.data;
            setUserData(data);
        } else errorCallback({
            message: "No data found for this user"
        });
    }
    function errorCallback(event) {
        var alertDialog = Ti.UI.createAlertDialog({
            title: event.title ? event.title : "NodeJSPOC",
            message: event.message ? event.message : "Found error while loading data"
        });
        alertDialog.show();
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "userProfile";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    $.__views.wrapper = Ti.UI.createView({
        width: Ti.UI.FILL,
        height: Ti.UI.FILL,
        layout: "vertical",
        backgroundColor: "black",
        id: "wrapper"
    });
    $.__views.wrapper && $.addTopLevelView($.__views.wrapper);
    $.__views.navBar = Alloy.createController("navBar", {
        id: "navBar",
        settings: "true",
        __parentSymbol: $.__views.wrapper
    });
    $.__views.navBar.setParent($.__views.wrapper);
    $.__views.topSection = Ti.UI.createView({
        top: 10,
        layout: "horizontal",
        width: Ti.UI.FILL,
        height: 120,
        id: "topSection"
    });
    $.__views.wrapper.add($.__views.topSection);
    $.__views.leftSection = Ti.UI.createView({
        top: 0,
        height: Ti.UI.FILL,
        width: 100,
        left: 10,
        id: "leftSection"
    });
    $.__views.topSection.add($.__views.leftSection);
    $.__views.profilePic = Ti.UI.createImageView({
        height: 80,
        width: 80,
        image: "/images/defaultProfile.png",
        id: "profilePic"
    });
    $.__views.leftSection.add($.__views.profilePic);
    $.__views.rightSection = Ti.UI.createView({
        top: 0,
        height: Ti.UI.FILL,
        left: 0,
        width: Ti.UI.FILL,
        layout: "vertical",
        id: "rightSection"
    });
    $.__views.topSection.add($.__views.rightSection);
    $.__views.name = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        color: "#ffffff",
        id: "name",
        text: "Test",
        left: "10",
        top: "30"
    });
    $.__views.rightSection.add($.__views.name);
    $.__views.designation = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        color: "#ffffff",
        id: "designation",
        text: "Test Engineer",
        left: "10"
    });
    $.__views.rightSection.add($.__views.designation);
    $.__views.__alloyId1 = Ti.UI.createView({
        height: 1,
        width: Ti.UI.FILL,
        left: "0",
        right: "0",
        backgroundColor: "#ffe1b5",
        bottom: 0,
        id: "__alloyId1"
    });
    $.__views.wrapper.add($.__views.__alloyId1);
    $.__views.bottomSection = Ti.UI.createScrollView({
        layout: "vertical",
        top: 10,
        id: "bottomSection"
    });
    $.__views.wrapper.add($.__views.bottomSection);
    $.__views.__alloyId2 = Ti.UI.createView({
        top: 10,
        height: 45,
        width: Ti.UI.FILL,
        id: "__alloyId2"
    });
    $.__views.bottomSection.add($.__views.__alloyId2);
    $.__views.empIdTitle = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        color: "#ffffff",
        left: 10,
        textAlign: "left",
        id: "empIdTitle",
        text: "Employee Id:"
    });
    $.__views.__alloyId2.add($.__views.empIdTitle);
    $.__views.empId = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: 150,
        color: "#ffffff",
        right: 10,
        textAlign: "right",
        id: "empId",
        text: "134"
    });
    $.__views.__alloyId2.add($.__views.empId);
    $.__views.__alloyId3 = Ti.UI.createView({
        height: 1,
        width: Ti.UI.FILL,
        left: 10,
        right: 10,
        backgroundColor: "#ffe1b5",
        bottom: 0,
        id: "__alloyId3"
    });
    $.__views.__alloyId2.add($.__views.__alloyId3);
    $.__views.__alloyId4 = Ti.UI.createView({
        top: 10,
        height: 45,
        width: Ti.UI.FILL,
        id: "__alloyId4"
    });
    $.__views.bottomSection.add($.__views.__alloyId4);
    $.__views.emailIdTitle = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        color: "#ffffff",
        left: 10,
        textAlign: "left",
        id: "emailIdTitle",
        text: "Email Id:"
    });
    $.__views.__alloyId4.add($.__views.emailIdTitle);
    $.__views.emailId = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: 150,
        color: "#ffffff",
        right: 10,
        textAlign: "right",
        id: "emailId",
        text: "test@gmail.com"
    });
    $.__views.__alloyId4.add($.__views.emailId);
    $.__views.__alloyId5 = Ti.UI.createView({
        height: 1,
        width: Ti.UI.FILL,
        left: 10,
        right: 10,
        backgroundColor: "#ffe1b5",
        bottom: 0,
        id: "__alloyId5"
    });
    $.__views.__alloyId4.add($.__views.__alloyId5);
    $.__views.__alloyId6 = Ti.UI.createView({
        top: 10,
        height: 45,
        width: Ti.UI.FILL,
        id: "__alloyId6"
    });
    $.__views.bottomSection.add($.__views.__alloyId6);
    $.__views.phoneNumberTitle = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        color: "#ffffff",
        left: 10,
        textAlign: "left",
        id: "phoneNumberTitle",
        text: "Phone Number:"
    });
    $.__views.__alloyId6.add($.__views.phoneNumberTitle);
    $.__views.phoneNumber = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: 150,
        color: "#ffffff",
        right: 10,
        textAlign: "right",
        id: "phoneNumber",
        text: "1133334"
    });
    $.__views.__alloyId6.add($.__views.phoneNumber);
    $.__views.__alloyId7 = Ti.UI.createView({
        height: 1,
        width: Ti.UI.FILL,
        left: 10,
        right: 10,
        backgroundColor: "#ffe1b5",
        bottom: 0,
        id: "__alloyId7"
    });
    $.__views.__alloyId6.add($.__views.__alloyId7);
    $.__views.__alloyId8 = Ti.UI.createView({
        top: 10,
        height: 45,
        width: Ti.UI.FILL,
        id: "__alloyId8"
    });
    $.__views.bottomSection.add($.__views.__alloyId8);
    $.__views.addressTitle = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: Ti.UI.SIZE,
        color: "#ffffff",
        left: 10,
        textAlign: "left",
        id: "addressTitle",
        text: "Address:"
    });
    $.__views.__alloyId8.add($.__views.addressTitle);
    $.__views.address = Ti.UI.createLabel({
        height: Ti.UI.SIZE,
        width: 150,
        color: "#ffffff",
        right: 10,
        textAlign: "right",
        id: "address",
        text: "Park Venue: 1, Noida"
    });
    $.__views.__alloyId8.add($.__views.address);
    $.__views.__alloyId9 = Ti.UI.createView({
        height: 1,
        width: Ti.UI.FILL,
        left: 10,
        right: 10,
        backgroundColor: "#ffe1b5",
        bottom: 0,
        id: "__alloyId9"
    });
    $.__views.__alloyId8.add($.__views.__alloyId9);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var params = arguments[0] || {}, apiClient = require("apiClient"), endPoints = require("endPoints");
    Alloy.Globals.iOS7 && ($.wrapper.top = 20);
    init();
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;