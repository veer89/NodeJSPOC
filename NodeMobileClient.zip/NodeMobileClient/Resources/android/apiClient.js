var http = require("http"), baseURL = "http://localhost:7000", appKeyUrl = "?appKey=ac5028363f1a32eed640de5d23195b499cc3146d";

exports.getUserInfo = function(data, successCallback, errorCallback) {
    var params = {
        format: "json",
        type: "GET",
        url: baseURL + "/users/query" + appKeyUrl,
        failure: errorCallback,
        success: successCallback
    };
    http.request(params);
};

exports.getUserInfoById = function(data, successCallback, errorCallback) {
    var params = {
        format: "json",
        type: "GET",
        url: baseURL + "/users/show/" + data.userId + appKeyUrl,
        failure: errorCallback,
        success: successCallback
    };
    http.request(params);
};