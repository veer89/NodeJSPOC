var Alloy = require("alloy"), _ = Alloy._, Backbone = Alloy.Backbone;

Alloy.Globals.iOS7 = false;

parseInt(Ti.Platform.version, 10) > 6 && (Alloy.Globals.iOS7 = true);

Alloy.createController("index");