function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "navBar";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    $.__views.navBar = Ti.UI.createView({
        width: Ti.UI.FILL,
        height: 45,
        backgroundColor: "#f29135",
        id: "navBar"
    });
    $.__views.navBar && $.addTopLevelView($.__views.navBar);
    $.__views.header = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "black",
        text: "User Profile",
        id: "header"
    });
    $.__views.navBar.add($.__views.header);
    $.__views.settings = Ti.UI.createView({
        height: Ti.UI.FILL,
        width: 45,
        right: 5,
        id: "settings"
    });
    $.__views.navBar.add($.__views.settings);
    $.__views.settingsImg = Ti.UI.createImageView({
        width: 30,
        height: 30,
        image: "/images/settings.png",
        id: "settingsImg"
    });
    $.__views.settings.add($.__views.settingsImg);
    exports.destroy = function() {};
    _.extend($, $.__views);
    arguments[0] || {};
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;